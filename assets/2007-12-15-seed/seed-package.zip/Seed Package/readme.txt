Thank you for downloading Seed flash game. 

This game is about splicing flowers and mutating their DNA!.

To play, simply unpack all files in the .zip to a folder, then open the .html file in your browser.

Have fun!


Made by Thomas van den Berg <www.noio.nl> 