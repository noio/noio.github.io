<?php
/*
	Plugin Name: Noio Iconized Bookmarks
	Plugin URI: http://www.noio.nl/
	Description: Plugin that creates a widget that displays favicon next to links
	Author: Thomas van den Berg
	Version: 0.7
	Author URI: http://www.noio.nl/
*/

/* 
	I (Thomas van den Berg) do not take any responsibility for damage that might
	occur to your WordPress database or website from using this plugin.
	*/

/*  Copyright 2008  Thomas van den Berg  (email : contact@noio.nl)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
	*/

function widget_noio_iconized_bookmarks($args){
	extract($args);
	
	$options = get_option("nib");
	if( !is_array($options)) { $options = array() ; }
	if( !isset($options['widget_args']) )
	{
		//$options['widget_args'] = 'title_li=Links&class=widget widget_noio_iconized_bookmarks';
	}
	
	$r = wp_parse_args($options['widget_args']);
		
	$r['title_before'] = $before_title; 
	$r['title_after'] = $after_title;
	$r['category_before'] = $before_widget;
	$r['category_after'] = $after_widget;
	
	list_iconized_bookmarks($r);
}

function noio_iconized_bookmarks_control(){
	$options = get_option("nib");
	if( !is_array($options)) { $options = array() ; }
	if( !isset($options['widget_args']))
	{
		$options['widget_args'] = 'title_li=Links&class=widget widget_noio_iconized_bookmarks';
	}

	if ($_POST['nib-widget-submit'])
	{
		$options['widget_args'] = $_POST['nib-args'];
		update_option("nib", $options);
	}

	?>
	<p>
		<label for="nib-args">list_iconized_bookmarks Arguments: </label>
		<input type="text" id="nib-args" name="nib-args" value="<?php echo $options['widget_args'];?>" />
		<input type="hidden" id="nib-widget-submit" name="nib-widget-submit" value="1" />
	</p>
	<?php

}


function list_iconized_bookmarks($args = '') {
	$defaults = array(
		'orderby' => 'name', 'order' => 'ASC',
		'limit' => -1, 'category' => '', 'exclude_category' => '',
		'category_name' => '', 'hide_invisible' => 1,
		'show_updated' => 0, 'echo' => 1,
		'categorize' => 1, 'title_li' => __('Bookmarks'),
		'title_before' => '<h2>', 'title_after' => '</h2>',
		'category_orderby' => 'name', 'category_order' => 'ASC',
		'class' => 'linkcat', 'category_before' => '<li id="%id" class="%class">',
		'category_after' => '</li>'
		);

	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );
	$output = '';


	if ( $categorize ) {
		//Split the bookmarks into ul's for each category
		$cats = get_terms('link_category', array('name__like' => $category_name, 'include' => $category, 'exclude' => $exclude_category, 'orderby' => $category_orderby, 'order' => $category_order, 'hierarchical' => 0));

		foreach ( (array) $cats as $cat ) {
			$params = array_merge($r, array('category'=>$cat->term_id));
			$bookmarks = get_bookmarks($params);
			if ( empty($bookmarks) )
				continue;
			$output .= str_replace(array('%id', '%class'), array("linkcat-$cat->term_id", $class), $category_before);
			$catname = apply_filters( "link_category", $cat->name );
			$output .= "$title_before$catname$title_after\n\t<ul class='iconized_bookmarks'>\n";
			$output .= _walk_iconized_bookmarks($bookmarks, $r);
			$output .= "\n\t</ul>\n$category_after\n";
		}
	} else {


		//output one single list using title_li for the title
		$bookmarks = get_bookmarks($r);

		if ( !empty($bookmarks) ) {
			if ( !empty( $title_li ) ){
				$output .= str_replace(array('%id', '%class'), array("linkcat-$category", $class), $category_before);
				$output .= "$title_before$title_li$title_after\n\t<ul class='iconized_bookmarks'>\n";
				$output .= _walk_iconized_bookmarks($bookmarks, $r);
				$output .= "\n\t</ul>\n$category_after\n";
			} else {
				$output .= _walk_iconized_bookmarks($bookmarks, $r);
			}
		}
	}

	$output = apply_filters( 'wp_list_bookmarks', $output );

	if ( !$echo )
		return $output;
	echo $output;
}

function _walk_iconized_bookmarks($bookmarks, $r){
	foreach ($bookmarks as $bookmark){
		$output .= '<li>';
		$output .= '<img class="favicon" src="' . $bookmark->link_image .'"></img>';
		$output .= '<a href="' . $bookmark->link_url.'">';
		$output .= $bookmark->link_name;
		$output .= '</a></li>';
	}
	return $output;
}



function noio_iconize_bookmarks_add_options_page() {
	add_options_page("Iconized Bookmarks Settings", "N.I.B.", "manage_options", __FILE__, "noio_iconize_bookmarks_options_page");
}

function noio_iconize_bookmarks_options_page() {

	//Setting default options
	$defaults = array(
		'iconizer_default_icon' => '',
		'iconizer_categories' => '',
		'iconizer_skip_notes' => 'noio_do_not_change_icon'
	);
	
	$options = get_option("nib");
	if( !is_array($options)) { $options = array() ; }
	
	foreach($defaults as $key => $default){
		if(!isset($options[$key])){
			$options[$key] = $default;
		}
	}

	//The function that does the real work.
	function NIB_add_icons($localoptions) {
		global $wpdb;
		//permalinks query
		$sql = "SELECT link_url , link_image 
						FROM $wpdb->links 
						WHERE link_notes NOT LIKE %s";
		$result = $wpdb->get_results( $wpdb->prepare( $sql , '%'.$localoptions['iconizer_skip_notes'].'%'), ARRAY_N);
		
		$newicons = array();
		
		foreach($result as $link){
			$link_url = $link[0];
			$link_newicon = NIB_find_icon($link_url, $localoptions['iconizer_default_icon']);
			$newicons[$link_url] = $link_newicon;
			$singlereplace = "UPDATE $wpdb->links
												SET link_image = %s
												WHERE link_url = %s";
			$replaced = $wpdb->query( $wpdb->prepare($singlereplace, $link_newicon, $link_url));
		}
		
		return $newicons;
	}	
	
	//Function that finds a single icon
	function NIB_find_icon($url, $default_icon) {
		$fvc = noio_locate_icon($url);
		if($fvc){ 
			return $fvc; 
		} else { 
			return $default_icon; 
		}
	}
	
	//Run the update function if admin panel was just posted.
	if(isset($_POST['nib_settings_submit'])){
		$message = "Settings submitted. Icons updated.";
		$options['iconizer_skip_notes'] = $_POST['nib_settings_skip'];
		$options['iconizer_default_icon'] = $_POST['nib_settings_defaulticon'];
		
		$result = NIB_add_icons($options);
		update_option("nib",$options);
		
	}
	
	//The panel itself.
	?>
	<div class="wrap">
	<h2>Noio Iconize Bookmarks</h2>
	<p><?php if(isset($message)){ echo $message;}?></p>
	<p><?php if(isset($result)){
		foreach($result as $key => $val){
			echo $key. " => " . $val . '<br />';
		}
	}?>
	<form method="post" action="options-general.php?page=noio_iconized_bookmarks.php">
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<label for"nib_settings_defaulticon">Default Icon:</label>
					</th>
					<td>
						This is the URL of a default favicon that will be used when a website's favicon cannot be found, or it has none.
						<input name="nib_settings_defaulticon" type="text" id="nib_settings_defaulticon" value="<?php echo $options['iconizer_default_icon']?>" style="width:300px;" />
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label for"nib_settings_skip">Skip when notes contain:</label>
					</th>
					<td>
						If the text in this field is present in the "Notes" field of a link, that link's image will not be changed.
						<input name="nib_settings_skip" type="text" id="nib_settings_skip" value="<?php echo $options['iconizer_skip_notes']?>" style="width:300px;" />
					</td>
				</tr>
			</tbody>
		</table>
		<p class="submit"> 
			<strong>Warning, this will overwrite existing information in the Image field of your links.</strong><br />
			&raquo; &raquo; &raquo;
			<input name="nib_settings_submit" value="Update Icons" type="submit" />
			&raquo; &raquo; &raquo; Please be patient after starting the update. &raquo; &raquo; &raquo;
		</p>
	</form>
	<?php
}

/*
Favicon Getter
Description: Defines a function to get a favicon from a URL.
Author: Jeff Minard
Author URI: http://thecodepro.com/
*/

/*
* @return boolean/string
* @param  string $url
* @desc  Attempts to find and return a favicon url based on $url
*/

function noio_locate_icon($url) {

	// start by fetching the contents of the URL they left...
	if( $html = @file_get_contents($url) ) {

		if (preg_match('/<link[^>]+rel="(?:shortcut )?icon"[^>]+?href="([^"]+?)"/si', $html, $matches)) {
			// Attempt to grab a favicon link from their webpage url

			$linkUrl = html_entity_decode($matches[1]);
			if (substr($linkUrl, 0, 1) == '/') {
				$urlParts = parse_url($url);
				$faviconURL = $urlParts['scheme'].'://'.$urlParts['host'].$linkUrl;
			} else if (substr($linkUrl, 0, 7) == 'http://') {
				$faviconURL = $linkUrl;
			} else if (substr($url, -1, 1) == '/') {
				$faviconURL = $url.$linkUrl;
			} else {
				$faviconURL = $url.'/'.$linkUrl;
			}

		} else {
			// If unsuccessful, attempt to "guess" the favicon location

			$urlParts = parse_url($url);
			$faviconURL = $urlParts['scheme'].'://'.$urlParts['host'].'/favicon.ico';

		}

		// Run a test to see if what we have attempted to get actually exists.
		if( $faviconURL_exists = url_validate($faviconURL) )
			return $faviconURL;

	} 

	// Finally, if we haven't 'returned' yet then there is nothing to see here.
	return false;
}
/*
* @return boolean
* @param  string $link
* @desc  Checks to see if $link actually exists (HTTP-Code: 200|30*, etc)
*/
function url_validate( $link ) {
		
	$url_parts = @parse_url( $link );

	if ( empty( $url_parts["host"] ) )
		return false;

	if ( !empty( $url_parts["path"] ) ) {
		$documentpath = $url_parts["path"];
	} else {
		$documentpath = "/";
	}

	if ( !empty( $url_parts["query"] ) )
		$documentpath .= "?" . $url_parts["query"];

	$host = $url_parts["host"];
	$port = $url_parts["port"];
	
	if ( empty($port) )
		$port = "80";

	$socket = @fsockopen( $host, $port, $errno, $errstr, 30 );
	
	if ( !$socket )
		return false;
		
	fwrite ($socket, "HEAD ".$documentpath." HTTP/1.0\r\nHost: $host\r\n\r\n");

	$http_response = fgets( $socket, 22 );

	$responses = "/(200 OK)|(30[0-9] Moved)/";
	if ( preg_match($responses, $http_response) ) {
		fclose($socket);
		return true;
	} else {
		return false;
	}

}

/* INITIALIZATION */
function widget_noio_iconized_bookmarks_init(){
	register_sidebar_widget(__('Iconized Bookmarks'), 'widget_noio_iconized_bookmarks');
	register_widget_control(   'Iconized Bookmarks', 'noio_iconized_bookmarks_control', 250, 200 );
}
add_action("plugins_loaded", "widget_noio_iconized_bookmarks_init");
add_action('admin_menu', 'noio_iconize_bookmarks_add_options_page'); 
?>